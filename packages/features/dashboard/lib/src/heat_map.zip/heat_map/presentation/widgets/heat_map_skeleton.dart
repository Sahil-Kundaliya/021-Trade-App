import 'package:core_ui/core_ui.dart';
import 'package:flutter/material.dart';

class HeatMapSkeleton extends StatelessWidget {
  const HeatMapSkeleton({this.height, this.shimmer = true, super.key});

  final double? height;
  final bool shimmer;

  @override
  Widget build(BuildContext context) {
    final mapHeight = height ?? AppSizes.heatMapMinHeight;
    final grid = SizedBox(
      height: mapHeight,
      child: const _HeatMapSkeletonGrid(),
    );
    return shimmer ? AppShimmer(child: grid) : grid;
  }
}

class _HeatMapSkeletonGrid extends StatelessWidget {
  const _HeatMapSkeletonGrid();

  @override
  Widget build(BuildContext context) {
    return const Row(
      children: [
        Expanded(flex: 5, child: _Cell(shade: 1)),
        SizedBox(width: AppSpacing.xs),
        Expanded(
          flex: 4,
          child: Column(
            children: [
              Expanded(flex: 3, child: _Cell(shade: 0)),
              SizedBox(height: AppSpacing.xs),
              Expanded(
                flex: 2,
                child: Row(
                  children: [
                    Expanded(child: _Cell(shade: 2)),
                    SizedBox(width: AppSpacing.xs),
                    Expanded(child: _Cell(shade: 1)),
                  ],
                ),
              ),
              SizedBox(height: AppSpacing.xs),
              Expanded(
                child: Row(
                  children: [
                    Expanded(flex: 2, child: _Cell(shade: 0)),
                    SizedBox(width: AppSpacing.xs),
                    Expanded(child: _Cell(shade: 2)),
                    SizedBox(width: AppSpacing.xs),
                    Expanded(child: _Cell(shade: 1)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _Cell extends StatelessWidget {
  const _Cell({required this.shade});

  final int shade;

  @override
  Widget build(BuildContext context) {
    final colors = context.appColors;
    final animatedGrey = shimmerColorOf(context);
    final fill = Color.lerp(
      animatedGrey,
      shade == 0 ? colors.skeletonBase : colors.skeletonHighlight,
      shade == 2 ? 0.5 : 0.28,
    )!;
    return ColoredBox(
      color: colors.surface,
      child: DecoratedBox(
        decoration: BoxDecoration(
          color: fill,
          borderRadius: AppRadius.xsBorderRadius,
          border: Border.all(
            color: colors.borderSubtle,
            width: AppBorders.thin,
          ),
        ),
      ),
    );
  }
}
